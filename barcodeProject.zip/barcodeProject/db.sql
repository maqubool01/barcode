CREATE TABLE `test`.`barcodeTest` ( `bcode` VARCHAR(12) NOT NULL , `name` VARCHAR(30) NOT NULL , `email` VARCHAR(30) NOT NULL , `phone` VARCHAR(10) NOT NULL , `qty` INT(5) NOT NULL , `price` FLOAT NOT NULL , PRIMARY KEY (`bcode`)) ENGINE = InnoDB;


<?php
$con= mysql_connect("localhost","","") or die("Cannot connect. Check your Web Server.");
mysql_select_db("test",$con) or die ("Cannot connect to the database. Please check your host Connection");
?>
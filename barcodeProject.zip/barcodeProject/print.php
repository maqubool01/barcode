<html>
<body>
<?php


require_once('dbconnect.php');
$txtbarcode = $_GET['barcode'];
$result=mysql_query("SELECT bcode, name, phone, qty, price from barcodetest where bcode = '".$txtbarcode."'");
while($row=mysql_fetch_array($result))
{
echo"<div align=center>";
include 'barcode128.php';
echo '<div style="height: 30%; width: 50%;">';
echo '<p>'.bar128(stripcslashes($row['bcode'])).'</p>';
echo '</div>';
echo $row['name'].'</br>';
echo $row['phone'].'</br>';
echo $row['qty'].'</br>';
echo $row['price'].'</br>';
}
mysql_close($con);
?>

</body>
</html>